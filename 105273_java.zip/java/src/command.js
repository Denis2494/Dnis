const LineAPI = require('./api');
const data = require('./form-data');
const aray = require('./isarray');
const sntp = require('./sntp');
const sshpk = require('./sshpk');
const thrift = require('./thrift');
const utf8 = require('./utf8');
const asynckit = ('./asynckit');
const async = ('./async');
const asy = ('./async-limiter');
const th = ('./curve-thrift');
const xtend = ('./xtend');
const thtp = ('./thrift-http');
const ShouldSyncException = require('./LineService');
const { Message, OpType, Location, Profile } = require('./curve-thrift/line_types');
const {
  LoginResultType,
  IdentityProvider,
  ContentType,
  LoginRequest
} = require('./curve-thrift/line_types');

let exec = require('child_process').exec;

class Donnigansmand extends LineAPI {

    constructor() {
        super();
        this.spamName = [];
    }

    get payload() {
        if(typeof this.messages !== 'undefined'){
            return (this.messages.text !== null) ? this.messages.text.split(' ').splice(1) : '' ;
        }
        return false;
    }

    async getProfile() {
        let { displayName } = await this._myProfile();
        return displayName;
    }

    async searchGroup(gid) {
        let listPendingInvite = [];
        let thisgroup = await this._getGroup(gid);
        if(thisgroup.invitee !== null) {
            listPendingInvite = thisgroup.invitee.map((key) => {
                return { mid: key.mid };
            });
        }
        let listMember = thisgroup.members.map((key) => {
            return { mid: key.mid };
        });
        return { 
            listMember,
            listPendingInvite
        }
    }
    
    async Ngentot() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let { listPendingInvite } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        for (var i = 0; i < listPendingInvite.length; i++) {
            if(listPendingInvite.length > 0){
                this._cancelMember(this.messages.to,[listPendingInvite[i].mid]);
            }
        }
        return;
    }
    async Ngentot() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let { listPendingInvite } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        for (var i = 0; i < listPendingInvite.length; i++) {
            if(listPendingInvite.length > 0){
                this._cancelMember(this.messages.to,[listPendingInvite[i].mid]);
            }
        }
        return;
    }
    async Ngentot() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let { listPendingInvite } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        for (var i = 0; i < listPendingInvite.length; i++) {
            if(listPendingInvite.length > 0){
                this._cancelMember(this.messages.to,[listPendingInvite[i].mid]);
            }
        }
        return;
    }

    async getSpeed() {
        let curTime = (new Date() / 1000);
        await this._sendMessage(this.messages, 'Gass Dent');
        const rtime = (new Date() / 1000) - curTime;
        await this._sendMessage(this.messages, `Time: ${rtime}  second`);
        return;
    }

    contact() {
        let msg = {
            text:null,
            contentType: 13,
            contentPreview: null,
            contentMetadata: 
            { mid: this.messages._from,
            displayName: 'JAVA BOTS LEMAH' }
        }
        Object.assign(this.messages,msg);
        this._sendMessage(this.messages);
    }

    async checkGroup() {
        this.messages.text = "GROUPLIST:\n\n";
        let gid = await this._getGroupsJoined();
        for(var i = 0; i < gid.length; i++){
            let gr = await this._getGroup(gid[i]);
            this.messages.text += "᪣ "+gr.name+"|"+gr.members.length+"\n";
        }
        this.messages.text += "\n"+gid.length+" GROUP JOINED";
        this._sendMessage(this.messages, this.messages.text);
        return;
    }

    async Nook() {
        let { listMember } = await this.searchGroup(this.messages.to);
        let updateGroup = await this._getGroup(this.messages.to);
        updateGroup.preventedJoinByTicket = true;
        this._updateGroup(updateGroup);
        for (var i = 0; i < listMember.length; i++) {
            if(!this.isAdminOrBot(listMember[i].mid)){
                this._kickMember(this.messages.to,[listMember[i].mid])
            }
        }
        return;
    }
}

module.exports = Donnigansmand;
